$(document).ready(function(){
	// solo para practicas de inicio
	// iniciar valores de combos	
	// setVar('cmbtablas',0,'tbads');
	// visorArchi();

	// tipo de origen de archivos: C-cargue, T-tabla
	setVar('cmbtipo',0,'C');

	$("#dgarchivos").datagrid('enableFilter');

})