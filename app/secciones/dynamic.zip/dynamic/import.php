<?php

include "functions.php";

// revision de campos 
// $equiva = camposEquiva('twclientes');

// $i=0;
// while($i<sizeof($equiva)){
	//0-id, 1-tabla, 2-campo, 3-dato, 4-tipo, 5-descr, 6-etabla
// 	$campo = $equiva[$i][2];
// 	$dato = $equiva[$i][3];

// 	echo '-->'.$campo.'-'.$dato.'<br>';

// 	$i++;

// }

// $cual = codigoMunicipio('MEDELLIN');
// echo $cual;

// echo occurr('MONTOYA AGUDELO JOSE DE JESUS',5);
echo occurr('NATES SOLANO LUIS JOHNY ENRIQUE',4);
// echo occurr('MEJIA VALLEJO JOSE DONELL',5);
// echo occurr('CANO RAFAEL',1);

?>